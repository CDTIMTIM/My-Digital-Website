/* ======================================== typing animation ================================================ */
var typed = new Typed(".Typing",{
    String:["","Web Designer","Web Developer","Editor"],
    typeSpeed:100,
    backSpeed:60,
    loop:true
})